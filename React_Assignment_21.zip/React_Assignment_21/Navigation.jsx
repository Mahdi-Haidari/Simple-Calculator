import { NavLink } from "react-router"

export default function Navigation(){
    return (
        <nav>
            <ul>
                <li>
                    <NavLink to="product" >Product</NavLink>
                </li>
                <li>
                    <NavLink to="about" >About</NavLink>
                </li>
            </ul>
        </nav> 
    )
}