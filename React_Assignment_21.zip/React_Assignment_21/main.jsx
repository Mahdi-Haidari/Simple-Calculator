import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import Product from "./Product";
import Navigation from "./Navigation";
import "./index.css";
import { BrowserRouter,Routes, Route } from "react-router";
import About from "./About";


createRoot(document.getElementById("root")).render(<StrictMode>

    <BrowserRouter>
    <Navigation></Navigation>
    <hr />
    <Routes>
        <Route path="product" element={<Product/>} ></Route>
        <Route path="about" element={<About/>} ></Route>
    </Routes>
    </BrowserRouter>
</StrictMode>);
