export default function Headphone(){
    return <div>
        <h2>Headphone</h2>
        <p>Price: $300</p>
    </div>
}