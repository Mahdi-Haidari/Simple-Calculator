
import { NavLink } from "react-router-dom"

export default function Navigation(){
    return <div>
        <ul>
            <li><NavLink to="phone" >Phone</NavLink></li>
            <li><NavLink to="laptop" >Laptop</NavLink></li>
            <li><NavLink to="headphone" >Headphone</NavLink></li>
        </ul>
    </div>
} 