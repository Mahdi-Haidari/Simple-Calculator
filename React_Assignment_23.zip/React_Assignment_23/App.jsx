import Phone from "./Phone";
import Laptop from "./Laptop";
import Headphone from "./Headphone";
import Navigation from "./Navigation";
import { BrowserRouter, Routes, Route } from "react-router-dom";

export default function App() {
  return (
    <div>
      <BrowserRouter>
        <Navigation></Navigation>
        <hr />
        <Routes>
          <Route path="phone" element={<Phone />}></Route>
          <Route path="laptop" element={<Laptop />}></Route>
          <Route path="headphone" element={<Headphone />}></Route>
        </Routes>
      </BrowserRouter>
    </div>
  );
}
