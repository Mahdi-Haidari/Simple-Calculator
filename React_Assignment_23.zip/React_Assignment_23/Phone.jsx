export default function Phone(){
    return <div>
        <h2>Phone</h2>
        <p>Price: $1000</p>
    </div>
}