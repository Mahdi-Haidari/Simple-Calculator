export default function Laptop(){
    return <div>
        <h2>Laptop</h2>
        <p>Price: $1500</p>
    </div>
}