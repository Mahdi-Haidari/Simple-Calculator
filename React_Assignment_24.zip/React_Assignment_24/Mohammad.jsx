export default function Mohammad(){
    return <div>
        <h2>Mohammad Ahmadi</h2>
        <p>class: File 4</p>
    </div>
}