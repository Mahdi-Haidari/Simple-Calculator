export default function Mahdi(){
    return <div>
        <h2>Mahdi Haidari</h2>
        <p>class: Web Design</p>
    </div>
}