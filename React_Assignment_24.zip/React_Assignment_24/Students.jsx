import { NavLink } from "react-router-dom"

export default function Students(){
    return <nav>
        <ul>
            <li  ><NavLink to="student1" >Mahdi Haidari</NavLink></li>
            <li  ><NavLink to="student2" >Mohammad Ahmadi</NavLink></li>
            <li  ><NavLink to="student3" >Reza Akbari</NavLink></li>
        </ul>
    </nav>
}