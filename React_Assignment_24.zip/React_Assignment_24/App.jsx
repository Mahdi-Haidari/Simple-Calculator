import NotFound from "./NotFound";
import Students from "./Students";
import Mahdi from "./Mahdi";
import Mohammad from "./Mohammad";
import Reza from "./Reza";
import { BrowserRouter, Routes, Route } from "react-router-dom";


export default function App() {
  return (
    <div>
      <BrowserRouter>
        <Students></Students>
        <hr /> <hr />
        <Routes>
            <Route path="*" element={<NotFound />} ></Route>
            <Route path="student1" element={<Mahdi />}  ></Route>
            <Route path="student2" element={<Mohammad />}  ></Route>
            <Route path="student3" element={<Reza />}  ></Route>
        </Routes>
      </BrowserRouter>
    </div>
  );
}
