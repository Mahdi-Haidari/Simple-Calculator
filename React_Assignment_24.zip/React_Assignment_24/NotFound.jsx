export default function NotFound(){
    return <div>
        <h2>404 Page Not Founde</h2>
        <p>Incorrect URL, please check the url or click the links to see details.</p>
    </div>
}