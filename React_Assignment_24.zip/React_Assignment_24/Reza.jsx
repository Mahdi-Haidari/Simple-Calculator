export default function Reza(){
    return <div>
        <h2>Reza Akbari</h2>
        <p>class: File 3</p>
    </div>
}