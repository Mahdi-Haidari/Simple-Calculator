import { Link, Routes, Route } from "react-router-dom";

function Home() {
  return <h1>Home Page</h1>;
}

function Movies() {
  return (
    <div>
      <h1>Movies</h1>

      <Link to="/movies/1">Interstellar</Link>
      <br />
      <Link to="/movies/2">Inception</Link>
      <br />
      <Link to="/movies/3">Avatar</Link>
    </div>
  );
}

function MovieDetails() {
  return <h1>Movie Details</h1>;
}

function About() {
  return <h1>About Page</h1>;
}

function NotFound() {
  return <h1>404 - Page Not Found</h1>;
}

export default function App() {
  return (
    <>
      <nav>
        <Link to="/">Home</Link> {" | "}
        <Link to="/movies">Movies</Link> {" | "}
        <Link to="/about">About</Link>
      </nav>

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/movies" element={<Movies />} />
        <Route path="/movies/:id" element={<MovieDetails />} />
        <Route path="/about" element={<About />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </>
  );
}