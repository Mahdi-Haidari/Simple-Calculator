import { NavLink } from "react-router"

export default function Navigation(){
    return (
        <nav>
            <ul className="flex gap-3 p-2 bg-slate-700 text-white " >
                <li>
                    <NavLink to="/">Home</NavLink>
                </li>
                <li>
                    <NavLink to="contact" >Contact</NavLink>
                </li>
                <li>
                    <NavLink to="about" >About</NavLink>
                </li>
            </ul>
        </nav> 
    )
}