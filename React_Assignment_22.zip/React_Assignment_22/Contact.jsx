export default function Contact(){

    return (
        <div>
            <h1>Contact</h1>
            <p>contact: +780317193 </p>
            <p>email: mahdihaidari864@gmail.com</p>
        </div>
    )

}