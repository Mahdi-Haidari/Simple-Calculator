import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import Navigation from "./Navigation";
import Contact from "./Contact";
import Home from "./Home";
import "./index.css";
import { BrowserRouter,Routes, Route } from "react-router";
import About from "./About";


createRoot(document.getElementById("root")).render(<StrictMode>

    <BrowserRouter>
    <Navigation></Navigation>
    <hr />
    <Routes>
        <Route path="/" element={<Home/>} ></Route>
        <Route path="about" element={<About/>} ></Route>
        <Route path="contact" element={<Contact/>} ></Route>
    </Routes>
    </BrowserRouter>
</StrictMode>);
